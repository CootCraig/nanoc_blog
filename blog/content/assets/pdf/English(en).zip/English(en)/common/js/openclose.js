jQuery(function($){
	//
	var ua = navigator.userAgent.toLowerCase();
	$('<link />',{
		type:'text/css',
		rel:'stylesheet',
		href:'common/css/orientation.css'
	}).appendTo('head');
	$(window).load(function(){
		$('body').css('display','block');
	})
	//
	$('#sideMenuInner a').click(function(){
		$(this).next().slideToggle(200)
			.parent().siblings() .children("ul:visible").slideToggle(200);
		if($(this).next().size()){
			return false;
		}
	});
	$("#openCloseMenu a").click(function(){
		return false;
	});
	//
	$('.NoteMark, .step-NoteMark')
		.click(function(){
			$(this).next().slideToggle(0, function(){
				if($(this).css('display') == 'none') {
					$(this).prev().removeClass('NoteMark2');
				}else{
					$(this).prev().addClass('NoteMark2');
				}
			});
		})
		.next()
			.addClass('NoteMarkU')
			.hide()
		;
})



/* ----- floating menu ----- */
$(function() {
	initialize();
	//
	var ua = navigator.userAgent.toLowerCase();
	//
	var hCap_disp_flag = document.location.pathname.toString().search(/\/index\.html$|\/$/);
	if(hCap_disp_flag!=-1){
		$('#hCap').css('display', 'block');
	}
	//
	if(ua.search(/iphone/) != -1 || ua.search(/android/) != -1 || ua.search(/windows phone/) != -1 || ua.search(/ipad/) != -1 || ua.search(/ipod/) != -1 || ua.search(/blackberry/) != -1){
		floatButton();
		$(window).load(function(){
			floatMenu();
		});
		//
		fontButton();
		//
		urlCheack();
		//
		//var cookie_val = document.cookie.split('=')[1];
		var cookie_val = 'm';
		var cookie_arr = document.cookie.split('; ');
		for(var i=0;i<cookie_arr.length;i++){
			if(cookie_arr[i].split('=')[0]=='NAME'){
				cookie_val = cookie_arr[i].split('=')[1]
			}
		}
		if(cookie_val == 's'){
			fontSizeCheck('s');
		}else if(cookie_val == 'l'){
			fontSizeCheck('l');
		}else{
			fontSizeCheck('m');
		}
	}else{
		printButton();
	}
	//
	if(ua.search(/iphone/) != -1 || ua.search(/ipad/) != -1 || ua.search(/ipod/) != -1){
		$('body').css('-webkit-text-size-adjust', 'none');
	}
	//
	$("#searchText").bind('keyup change', function() {
		searchClear();
	});
});

function nodeTable(value){
	if($("#_"+value).hasClass("List-close")){
		$("#_"+value).removeClass("List-close");
		$("#icon"+value).attr("src", "common/images/list_space.gif");
		
		var tagObj = $("."+value).get();
		for(var i=0; i<tagObj.length; i++){
			var classNum = tagObj[i].className;
			if(checkCSS(value, classNum)){
				var ie = navigator.userAgent.toLowerCase().search('msie');
				var ie_ver;
				if(ie!=-1){
					ie_ver = Number(navigator.userAgent.toLowerCase().split('msie ')[1].split(';')[0]);
				}
				if((ie!=-1) && (ie_ver<=7)){
					tagObj[i].style.display="block";
				}else{
					tagObj[i].style.display="table-row";
				}
			}
		}
	}else{
		$("."+value).hide();
		$("#_"+value).addClass("List-close");
		$("#icon"+value).attr("src", "common/images/list_plus.gif");
	}
}
function checkCSS(cssid, classNum){
	var items = classNum.split(" ");
	for(var i=0; i<items.length; i++){
		if(items[i] != cssid){
			if($("#_"+items[i]).hasClass("List-close")) return false;
		}
	}
	return true;
}


function initialize(){
	var tagObj = $(".StepTable").find("tr").get();
	var a = new Array();
	var b = new Array();
	var prlevel = 0;
	
	for(var i=0; i<tagObj.length; i++){
		var itlevel = 0;
		var tags = tagObj[i].childNodes;
		for(var l=0;l<tags.length; l++){
			if(tags[l].nodeType != 1) continue;
			var tagName = tags[l].className;
			if(tagName.indexOf("top") > 0) {
				var tt =tagName.slice(tagName.length - 4, tagName.length - 3);
				itlevel = parseInt(tagName.slice(tagName.length - 4, tagName.length - 3));
				if(prlevel >= itlevel) {
					listTop(tagObj, a, b);
				}
				a.push(itlevel);
				b.push(i);
			}else if(a.length > 0 && tagName.indexOf("level") > 0){
				itlevel = parseInt(tagName.slice(-1));
				listMid(tagObj, b, i);
			}
		}
		prlevel = itlevel;
		if(itlevel == 0){
			for(var n=0; n<b.length; n++){
				listTop(tagObj, a, b);
			}
		}
		
	}
	for(var l=0; l<b.length; l++){
		listTop(tagObj, a, b);
	}

}

function listTop(tagObj, a, b){
	var blast = b[b.length-1];
	
	var tags = tagObj[blast].childNodes;
	for(var i=0;i<tags.length; i++){
		if(tags[i].nodeType != 1) continue;
		if(tags[i].className.indexOf("top") > 0) {
			tags[i].setAttribute("id", "_"+blast);
			//tags[i].setAttribute("onclick", "nodeTable(" + blast + ", "+a[a.length-1]+")");
			$(tags[i]).click(function(){
				nodeTable(blast, a[a.length-1])
			});
			for(var j=0;j<tags[i].childNodes.length;j++){
				if(String(tags[i].childNodes[j].tagName).toLowerCase()=='p'){
					tags[i].childNodes[j].setAttribute("id", "p"+blast);;
				}
			}
			$("#p"+blast).append('<img id="icon' + blast + '" class="icon" src="common/images/list_space.gif" />');
		}
	}
	a.pop();
	b.pop();
	if(b.length > 0) listMid(tagObj, b, blast);
}
function listMid(tagObj, b, blast){
	tagObj[blast].className=b.toString().replace(/,/g, " ");
}


/* -----  ----- */
function floatMenu(){
	var fMenuTop = $("#floatMenu").offset().top;
	$(window).bind('scroll resize load', function () {
		var winTop = $(this).scrollTop();
		toFloat();
	});
	//
}

function toFloat(Flag){
	var ua = navigator.userAgent.toLowerCase();
	var scrollTop = parseInt($(this).scrollTop());
	$('#floatMenu').stop().animate({'opacity':'0.35'},0);
	if(ua.search(/android 2.1/) != -1 || ua.search(/iphone/) != -1){
		$("#floatMenu").css({position:'absolute', left: $(window).width() - 35, top: $(window).height() - 150 + scrollTop});
	}else{
		$("#floatMenu").css({position:'fixed', left: $(window).width() - 35, top:$(window).height() - 150});
	}
	$('#floatMenu').stop().animate({'opacity':'0.1'},2000);
}

function floatButton(){
	var txt = '<div id="floatMenu"><ul class="clearfix">';
	txt += '<li><a href="#subcontents" onclick="scrollView(\'subcontents\')"><img src="common/images/icon_manu.png" /></a></li>';
	txt += '<li><a href="#subtop" onclick="scrollView(\'subtop\')"><img src="common/images/icon_return.png" /></a></li>';
	txt += '</ul></div>';
	//
	$("#header").after(txt).prepend('<a id="subtop"></a>');
	$("#sideMenuInner").prepend('<a id="subcontents"></a>');
	//
	toFloat();
}

function scrollView(Id){
	$('#'+Id)[0].scrollIntoView(true);
}

// -----  ----- */
function fontButton(){
	var txt = '<div id="fontSize"><ul class="clearfix">';
	txt += '<li><a href="javascript:fontSizeCheck(\'s\');"><img src="common/images/icon_s.png" /></a></li>';
	txt += '<li><a href="javascript:fontSizeCheck(\'m\');"><img src="common/images/icon_m.png" /></a></li>';
	txt += '<li><a href="javascript:fontSizeCheck(\'l\');"><img src="common/images/icon_l.png" /></a></li>';
	txt += '</ul></div>';
	//
	$("#header").append(txt);
}

function fontSizeCheck(Size){
	setDay = new Date();
	setDay.setTime(setDay.getTime()+(365*1000*60*60*24));
	expDay = setDay.toGMTString();
	document.cookie='NAME='+Size+';path=/;expires='+expDay;
	if(Size == 's'){
		$('body').css('font-size', '75%');
	}else if(Size == 'm'){
		$('body').css('font-size', '100%');
	}else if(Size == 'l'){
		$('body').css('font-size', '125%');
	}else{
		void(0);
	}
}


/* ----- webfont ----- */
$(function() {
	var ua = navigator.userAgent.toLowerCase();
	if(ua.search(/android 2.1/) > -1 || ua.search(/android 1.6/) > -1)  fontPicture();
	//fontPicture();
});


function fontPicture(){
	var stylename = new Array('p.CautionMark','span.Webfont');
	
	for(var f = 0; f < stylename.length; f++){
		var objs = $(stylename[f]);
		for(var i = 0; i < objs.length; i++){
			objs[i].innerHTML = changeCharacter(objs[i].innerHTML);
		}
	}
}

function changeCharacter(txt){
	var cont = "";
	var i = 0
	while (i < txt.length) {
		var l = i + 1;
		if(txt.substring(i,i+1) == "<" || txt.substring(i,i+1) == "&") {
			for(var n=i;n<txt.length;n++){
				if(txt.substring(n,n+1) == ">" || txt.substring(n,n+1) == ";"){
					l = n+1;
					break;
				}
			}
		}
		
		if(txt.substring(i,i+1) == "<"){
			cont += txt.substring(i,l);
		}else{
    		cont += characterGlyph(txt.substring(i,l));
		}
		i = l;
	}
	
	return cont;
}

function characterGlyph(txt) {
	if(txt=="#") return '<img class="icon" src="common/images/font_warning.png" alt="warning"/>';
	if(txt=="!") return '<img class="icon" src="common/images/font_caution.png" alt="caution"/>';
	if(txt=="&lt;") return '<img class="icon" src="common/images/font_note.png" alt="note"/>';
	if(txt=="-") return '<img class="icon" src="common/images/font_song.png" alt="song"/>';
	if(txt==":") return '<img class="icon" src="common/images/font_folder.png" alt="folder"/>';
	if(txt==";") return '<img class="icon" src="common/images/font_folder2.png" alt="folder"/>';
	if(txt=="=") return '<img class="icon" src="common/images/font_directCurrent.png" alt="DC"/>';
	if(txt=="1") return '<img class="icon" src="common/images/font_search.png" alt="search"/>';
	if(txt=="6") return '<img class="icon" src="common/images/font_return.png" alt="return"/>';
	if(txt=="E") return '<img class="icon" src="common/images/font_seekdown.png" alt="track down"/>';
	if(txt=="F") return '<img class="icon" src="common/images/font_seekup.png" alt="track up"/>';
	if(txt=="G") return '<img class="icon" src="common/images/font_eject.png" alt="eject"/>';
	if(txt=="R") return '<img class="icon" src="common/images/font_cursorup.png" alt="up"/>';
	if(txt=="S") return '<img class="icon" src="common/images/font_cursordown.png" alt="down"/>';
	if(txt=="Á") return '<img class="icon" src="common/images/font_arrow_right.png" alt=""/>';
	if(txt=="Û") return '<img class="icon" src="common/images/font_tel_offhook1.png" alt="off hook"/>';
	if(txt=="Ý") return '<img class="icon" src="common/images/font_tel_onhook.png" alt="on hook"/>';
	if(txt=="ä") return '<img class="icon" src="common/images/font_Check.png" alt=""/>';
	if(txt=="ò") return '<img class="icon" src="common/images/font_fingerpointing_right.png" alt=""/>';
	if(txt=="ö") return '<img class="icon" src="common/images/font_circle.png" alt=""/>';
	if(txt=="Í") return '<img class="icon" src="common/images/font_square.png" alt=""/>';

	return txt;
}

// ----- print ----- */
function printButton(){
	var txt = '<div id="printButton"><ul class="clearfix">';
	txt += '<li><a href="javascript:printCSS(false);"><img src="common/images/icon_print1.png" alt="print" title="print" /></a></li>';
	txt += '<li><a href="javascript:printCSS(true);"><img src="common/images/icon_print2.png" alt="chapter print" title="chapter print" /></a></li>';
	txt += '</ul></div>';
	//
	$("#hCap").after(txt);
	//
	var txt = '<div id="previousButton"><ul class="clearfix">';
	txt += '<li><a href="javascript:printClear();"><img src="common/images/icon_previous.png" alt="" /></a></li>';
	txt += '</ul></div>';
	//
	$("#pathWay").append(txt);
}

function printCSS(value){
	$('<link />',{
		id: 'cssPrint',
		type:'text/css',
		rel:'stylesheet',
		href:'common/css/print.css'
	}).appendTo('head');
	//
	$('<link />',{
		type:'text/css',
		rel:'stylesheet',
		href:'common/css/print2.css',
		media: 'print'
	}).appendTo('head');
	//
	if(value) {
		selectMenu();
	}else{
		fontPicture();
		$('.NoteMark, .step-NoteMark').next().show();
	}
}

function printClear(){
	$('#cssPrint').remove();
	$('#contentsInner').show("fast", "swing");
	$('#searchResult').hide("fast", "swing");
	$('#searchResult').html('');
	
	$('.NoteMark, .step-NoteMark').removeClass('NoteMark2').next().hide();
	
	var items = $("div#pathWay span.current");
	items[items.length - 1].setAttribute("style", "display:inline-block;");
	var items = $("div#pathWay span.way");
	items[items.length - 1].setAttribute("style", "display:inline-block;");
}

function selectMenu(){
	var items = $("div#sideMenuInner li.select li a");
	if(items.length < 1){
		fontPicture(); return;
	}
	var txt = "";
	for(i=0;i<items.length;i++){
		txt += '<div id="page' + i.toString() + '"></div><br />';
	}

	$("div#searchResult").append(txt);
	
	for(i=0;i<items.length;i++){
		var iNum = 'contentsInner' + i.toString();
		if(i == items.length - 1){
			$("#page" + i.toString()).load(items[i] + ' #contentsInner', function(){
				fontPicture();
			});
		}else{
			$("#page" + i.toString()).load(items[i] + ' #contentsInner');
		}
	}
	
	$('#contentsInner').hide("fast", "swing");
	$('#searchResult').show("fast", "swing");

	var items = $("div#pathWay span.current");
	items[items.length - 1].setAttribute("style", "display:none;");
	var items = $("div#pathWay span.way");
	items[items.length - 1].setAttribute("style", "display:none;");
}

//
function urlCheack(){
	if(document.URL.indexOf('index.html') >= 0){
		$('div#hCap').show();
	}
}

//search
//
function searchKeyword(Flag){
	//
	var result_msg0 = "";
	var result_msg1 = " search results found.";
	var result_msg2 = "Sorry, no results found.";
	var rep_spchar = [
		['&amp;', '&'],
		['&Dagger;', '‡'],
		['&dagger;', '†'],
		['&deg;', '°'],
		['&gt;', '>'],
		['&le;', '≤'],
		['&lt;', '<'],
		['&micro;', 'µ'],
		['&mu;', 'μ'],
		[' ', '&nbsp;'],
		['&Omega;', 'Ω'],
		['&plusmn;', '±'],
		['&quot;', '"']
	];
	var keyword = '';
	keyword = document.getElementById('searchText').value;
	//
	for(var i=0;i<rep_spchar.length;i++){
		var regExp = new RegExp(rep_spchar[i][1], 'g');
		keyword = keyword.replace(regExp, rep_spchar[i][0]);
	}
	//console.log(':::'+keyword);
	/*
	var get_cookie = unescape(document.cookie);
	if(!keyword && !Flag){
		if(get_cookie){
			var cookie_keyword = '';
			//var cookie_mtype = '';
			for(var i=0;i<get_cookie.split(';').length;i++){
				if(get_cookie.split(';')[i].search('SEARCHWORD=')!=-1){
					cookie_keyword = get_cookie.split(';')[i].split('=')[1];
					console.log("cookie_keyword = get_cookie.split(';')[i].split('=')[1];");
				}
			}
		keyword = cookie_keyword;
		}
	}
	*/
	//
	var result = document.getElementById('searchResult');
	var reg_spchar = ['[', ']', '(', ')', '{', '}', '.', '^', '+', '*', '?', '$', '|', '-', '\\'];
	var tmp_str = ''
	for(var i=0;i<keyword.length;i++){
		for(var j=0;j<reg_spchar.length;j++){
			if(keyword[i] == reg_spchar[j]){
				tmp_str += '\\'
			}
		}
		tmp_str += keyword.substring(i,(i+1))
	}
	keyword = tmp_str;
	var keyword_array = keyword.split(/ |　/);
	var out_str = '';
	var count = 0;
	//
	var keywordReg = new Array();
	for(var i=0;i<keyword_array.length;i++){
		if(keyword_array[i]){
			keywordReg.push(RegExp('(' + keyword_array[i] + ')', 'gi'));
		}
	}
	//
	var count = 0;
	var out_str = '';
	if (keyword && keywordReg.length) {
		out_str += '<dl>';
		for (var i = 0; i < data.length; i++) {
			var hit_pos = -1;
			var all_hit = true;
			for(var j=0;j<keywordReg.length;j++){
				if(data[i][3].toLowerCase().search(keywordReg[j])==-1){
					all_hit = false;
				} else{
					hit_pos = data[i][3].toLowerCase().search(keywordReg[j]);
				}
			}
			//
			if((all_hit)){
				//
				var title_str = data[i][2];
				var url_str = data[i][0].replace(/^\//, '');
				out_str += '<dt><a href="' + url_str + '" rel="external">';
				
				for(var j=0;j<keyword_array.length;j++){
					title_str = title_str.replace(keywordReg[j], '<span style="background:yellow;color:#000;">$1</span>');
				}
				out_str += title_str;
				out_str += '</a></dt>';
				//
				var txt_str = data[i][3].substring((hit_pos-40),(hit_pos+40));
				out_str += '<dd>………';
				for(var j=0;j<keyword_array.length;j++){
					txt_str = txt_str.replace(keywordReg[j], '<span style="background:yellow;color:#000;">$1</span>');
				}
				out_str += txt_str;
				out_str += '………</dd>';
				//
				count++;
			}
		}
		out_str += '</dl>';
		if(count){
			result.innerHTML = '<p>'+ result_msg0 + count + result_msg1 + '</p>' + out_str;
			if(keyword){
				setCookie('SEARCHWORD', keyword, 367);
				//console.log("setCookie('SEARCHWORD', keyword, 367)");
			}
		} else {
			result.innerHTML = '<p id="resultMsg">' + result_msg2 + '</P>';
		}
	} else {
		result.innerHTML = '<p id="resultMsg">' + result_msg2 + '</P>';
	}
	$('#pathWay').hide();
	//
	$('#printButton').hide();
	//
	$('#contentsInner').hide("fast", "swing");
	$('#searchResult').show("fast", "swing");
}

function searchClear(){
	if( $("#searchText").val()!="" ) return;
	
	$('#pathWay').show();
	$('#printButton').show();
	$('#contentsInner').show("fast", "swing");
	$('#searchResult').hide("fast", "swing");
	$('#searchResult').html('');
}

//
function setCookie(c_name, value, expiredays){
	setDay = new Date();
	setDay.setTime(setDay.getTime()+(365*1000*60*60*24));
	expDay = setDay.toGMTString();
	document.cookie=c_name+'='+value+';path=/;expires='+expDay;
}